# Welcome to spotPython

For official information see [SPOTSeven](https://www.spotseven.de/spot/)


