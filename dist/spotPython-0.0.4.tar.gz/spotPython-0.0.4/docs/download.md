# Install spotPython

    pip install spotPython
